﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JOKER
{
    public partial class Form3 : Form

    {
        private Form4 Form4;
        internal object Labe7;

        public Form3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 = new Form4();
            Form4.Show(this);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 = new Form4();
            Form4.Show(this);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form4 = new Form4();
            Form4.Show(this);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string filename = Application.StartupPath;

            filename = Path.GetFullPath(

                Path.Combine(filename, "C: \Users\PC\Desktop\коллектив\zadanie_l2_09.02.03\Ресурсы\Словарь данных.pdf"));

            wbrPdf.Navigate(filename);
        }
    }
}
