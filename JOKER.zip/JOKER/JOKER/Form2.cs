﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JOKER
{
    public partial class Form2 : Form
    {
        private Form3 Form3;
        public Form2()
        {
            InitializeComponent();
            label7.Text = textBox1.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 = new Form3();
            Form3.Show(this);
            Form3 f3 = new JOKER.Form3();
            f3.Show();
            f3.label8.Text = label7.Text;
            f3.label4.Text = label8.Text;
            f3.label16.Text = label11.Text;
            float sum = Convert.ToInt32(textBox1.Text);
            float srokvk = Convert.ToInt32(textBox2.Text);
            float monrefill = Convert.ToInt32(textBox3.Text);
            float prsum1 = (sum / 100 * 8) / 12 * srokvk;
            float prsum2 = ((sum + monrefill) / 100 * 5) / 12 * srokvk;
            float prsum3 = ((sum + monrefill) / 100 * 6) / 12 * srokvk;
            float yearsum1 = sum + prsum1;
            float yearsum2 = sum + prsum2;
            float yearsum3 = sum + prsum3;
            f3.label11.Text = yearsum1.ToString();
            f3.label3.Text = yearsum2.ToString();
            f3.label15.Text = yearsum3.ToString();
            Hide();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox1.Text += trackBar1.Value;
            //textBox1.Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            label7.Text = textBox1.Text;
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            textBox2.Text = "";
            textBox2.Text += trackBar2.Value;
            Double S, SP, SG, M;
            Double SN = Convert.ToDouble(textBox1.Text);
            Double SR = Convert.ToDouble(textBox2.Text);

            SP = SN / 100 * 8;
            SG = SN + SP;
            M = SG / 12;
            S = SN + M * SR;
            string f = Convert.ToString(S);
            label8.Text = f;
            //textBox2.Text = "";
        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {
            textBox3.Text = "";
            textBox3.Text += trackBar3.Value;
            Double S, S2, SP, SP2, SG, SG2, M, M2;
            Double SN = Convert.ToDouble(textBox1.Text);
            Double SR = Convert.ToDouble(textBox2.Text);
            Double SE = Convert.ToDouble(textBox3.Text);

            SN = SN + SE;
            SP = SN / 100 * 5;
            SP2 = SN / 100 * 6;
            SG = SN + SP;
            SG2 = SN + SP2;
            M = SG / 12;
            M2 = SG2 / 12;
            S = SN + M + SR;
            S2 = SN + M2 + SR;
            string f = Convert.ToString(S);
            string f2 = Convert.ToString(S2);
            label11.Text = f;
            label8.Text = f2;
            //textBox3.Text = "";
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            label8.Text = textBox2.Text;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            label11.Text = textBox3.Text;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
